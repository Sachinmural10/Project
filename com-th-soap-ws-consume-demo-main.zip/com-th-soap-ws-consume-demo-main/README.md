# com-th-soap-ws-consume-demo
 WS Consume demo app for TH trainees Dec 2021
